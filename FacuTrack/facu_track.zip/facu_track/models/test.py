from my_location import GetUserlocation

user_location_checker = GetUserlocation()
result = user_location_checker.test()
print(result)